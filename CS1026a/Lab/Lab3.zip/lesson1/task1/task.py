# TODO: type solution here
x=5

#is x > 5?

#if statemnet here to check if x is greater than 5:
    print("X is larger than 5")
#else statement here
    print("X is smaller than or equal to 5")