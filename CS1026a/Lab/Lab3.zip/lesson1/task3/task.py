# TODO: type solution here
from datetime import datetime
hour = datetime.now().hour
#place your code here
print("Good {}, world".format(timeOfDay))