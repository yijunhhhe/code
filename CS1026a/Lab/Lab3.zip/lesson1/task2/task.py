# TODO: type solution here
a=12
b=7
t =True
c='e'

print((a > 0) ?  (b > 0))

print(('a' > c)  ? ('E' != c))

print((a % b != 0) and (b * 2 ? a))

print((t ? not(a > b)) and t)