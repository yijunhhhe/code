# TODO: type solution here
text = open("text.txt","r")
myfile=open("myfile.txt","w")
# add your code here