# TODO: type solution here
f = open("data.csv","r")
#add your code here
f.close()