# TODO: type solution here
text = open("text.txt","r")
#add your code here
