# TODO: type solution here
#create your function here

someNumbers = [1,2,3,4,5,6,7,8,9,0]
someOtherNumbers = [11,22,33,44,55,66,77,88,99,100]
print(someSame(someNumbers,someOtherNumbers))
someMoreNumbers = [111,222,333,444,555,6,777,888,999,1000]
print(someSame(someNumbers,someMoreNumbers))
