# TODO: type solution here
def zFirst(words):
    #finish the function here

words=["hello","good","nice","as","at","baseball","absorb","sword","a","tall","so","bored","silver","hi"
,"pool","we","I","am","seven","Do","you","want","ants","because","that's","how","you","get","zebra","zealot","Zaire"]
print(zFirst(words))
