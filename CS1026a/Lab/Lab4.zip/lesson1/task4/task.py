# TODO: type solution here
import random
name = input("please enter your name")

#place your code here