# TODO: type solution here
count = 1
#place loop here
    print(count)
    #there is a missing statement here
