# TODO: type solution here
#place your outer loop here
    for x in range(1,11):
        print(x)