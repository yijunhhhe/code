import math
#check if number is prime not overly efficient
def prime(n):
    if n==1 or n==0:
        return False
    for x in range(2,int(math.sqrt(n)+1)):
        if n%x == 0:
            return False
    return True
#add your code here
print(dict)
