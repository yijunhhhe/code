sentence ="I had such a horrible day. It was awful so bad sigh. It could not have been worse but actually though "\
          +"such a terrible horrible awful bad day."

makeItHappy ={"horrible":"amazing","bad":"good","awful":"awesome","worse":"better","terrible":"great"}

#place your code here

print(newString)


