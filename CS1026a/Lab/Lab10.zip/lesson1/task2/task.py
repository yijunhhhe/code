# TODO: type solution here
#place your Dinosaur class here



d1= Dinosaur()
d2= Dinosaur()
d3 = Dinosaur()

d1.setType("T-Rex")
d2.setType("Velociraptor")
d3.setType("Stegosaurus")

print(d1.getType(),d2.getType(),d3.getType())
