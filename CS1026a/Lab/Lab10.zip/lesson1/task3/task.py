# TODO: type solution here
#place your code here

coffee = Coffee()
cream= Cream()

print(coffee+cream)