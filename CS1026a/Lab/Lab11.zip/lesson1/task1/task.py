# TODO: type solution here
#place your code here