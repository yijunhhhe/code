# TODO: type solution here
def addNumbers(a,b):
  #place your code here

print(addNumbers(3,5))
