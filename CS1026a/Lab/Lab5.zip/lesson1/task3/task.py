# TODO: type solution here

#make helloWorld here

#make helloWorldNTimes here



def main():
    helloWorldNTimes(7)


main()