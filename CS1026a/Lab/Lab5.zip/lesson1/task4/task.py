# TODO: type solution here
#make isMultiple here

def checkMultiples():
    for i in range(1,100):
        cur = isMultiple(i)
        if cur != -1:
            print(cur)


checkMultiples()