from test_helper import run_common_tests, failed, passed, get_answer_placeholders,get_file_output


def test_answer_placeholders():
    placeholders = get_answer_placeholders()
    placeholder = placeholders[0]
    if placeholder == "":  # TODO: your condition here
        passed()
    else:
        failed()
def testOutput():
    output = get_file_output()
    if  output[0] =="120" and output[1] == "5040" and output[2] == "362880":
        passed()
    else:
        failed()

if __name__ == '__main__':
    run_common_tests()
    testOutput()
    # test_answer_placeholders()       # TODO: uncomment test call


