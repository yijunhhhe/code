# TODO: type solution here
# write your function here

print(factorial(5))
print(factorial(7))
print(factorial(9))